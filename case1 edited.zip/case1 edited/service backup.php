// if(isset($_SESSION['details'])){
//     session_unset($_SESSION['details']);
//     } 
<a href="services-details.php?details=<?php echo $value['service_id']; ?>" class="btn btn-primary">View Details</a> 
        </div>